<?php

$user = $_SESSION['user'];
?>